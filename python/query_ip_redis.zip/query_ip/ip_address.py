#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/7/13 0013 上午 10:12
# @Author  : ligang

import sys
import urllib2
import re
import json
import redis
from ipip import IPX
from collections import OrderedDict


dic = OrderedDict()
a = sys.stdout
reload(sys)
sys.setdefaultencoding('utf-8')


add_url = "http://testapiserver.map.so.com:8008/ipquery/server/uid__qiyeanquan_tianyan/?ip="
IPX.load("./mydata4vipday2.datx")
red = redis.Redis(host='127.0.0.1', port=6800, password='xiaochaochao', db=4)

def getPage(url):
    req = urllib2.Request(url)
    data = urllib2.urlopen(req, timeout=20).read()
    return data


def is_intra_ip(ip):
    try:
        d1, d2, d3, d4 = ip.strip().split('.')
        d1 = int(d1)
        d2 = int(d2)
        if d1 == 10:
            return True
        elif d1 == 172 and 16 <= d2 <= 31:
            return True
        elif d1 == 192 and d2 == 168:
            return True
        else:
            return False
    except:
        return False


def ip_qualify(ip):
    ipv4_flag = re.match(
        r'^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$',
        ip) is not None
    return ipv4_flag


def get_ip_address(ip, city_dict):
    if not ip_qualify(ip):
        return None
    if is_intra_ip(ip):
        return None
    ipip_result = IPX.find(ip).split("\t")
    if len(ipip_result) > 2:
        province_ipip = ipip_result[1]
        city_ipip = ipip_result[2]
        latitude_ipip = ipip_result[5]
        longitude_ipip = ipip_result[6]

    '''
    map数据字段："adcode":"310115"，"location":"31.18918,121.57188"，"addr":"上海,上海,浦东新区,高科西路,,310115"
                "radius":"19376", "occupy":"1.0","street":"高科西路"
    '''
    map_result = json.loads(getPage(add_url + ip))
    if map_result['adcode'] != "":
        try:
            geo_location = city_dict[map_result['adcode']].split("|")
        except:
            geo_location = []
        if len(geo_location) == 0:
            return [
                "1",
                province_ipip,
                city_ipip,
                '',
                '',
                latitude_ipip,
                longitude_ipip]
        geo_city = geo_location[1]
        if not geo_city.startswith(city_ipip):
            return [
                "2",
                province_ipip,
                city_ipip,
                '',
                '',
                latitude_ipip,
                longitude_ipip]
        geo_radius = float(map_result["radius"])
        geo_occupy = float(map_result["occupy"])
        if geo_radius <= 1000 and geo_occupy >= 0.7:
            map_location = map_result["location"].split(",")
            map_latitude = map_location[0]
            map_longitude = map_location[1]
            map_street = map_result["street"]
            try:
                district = geo_location[2]
            except:
                district = ""
            return [
                "3",
                province_ipip,
                city_ipip,
                district,
                map_street,
                map_latitude,
                map_longitude]
        else:
            return [
                "4",
                province_ipip,
                city_ipip,
                '',
                '',
                latitude_ipip,
                longitude_ipip]
    else:
        return [
            "5",
            province_ipip,
            city_ipip,
            '',
            '',
            latitude_ipip,
            longitude_ipip]


city_dict = json.loads(getPage('http://m.map.so.com/cms/map/data/adcode.json'))


def qurey_ip():
    ip = raw_input("请输入查询ip：")  # 获取查询ip
    if ip == "":
        print ip
    result1 = red.hget('ip', ip)  # 首先从redis数据库中查询ip
    if result1 is not None:
        print result1  # 若redis库中存在直接返回
    else:
        try:
            result = get_ip_address(ip, city_dict)  # 若redis库中不存在，则调用查询程序
        except:
            print ip
        if result is not None:
            try:
                tag = int(result[0])
                province = result[1]
                city = result[2]
                district = result[3]
                map_street = result[4]
                map_latitude = result[5]
                map_longitude = result[6]
                if tag != 3:
                    location_tag = 'ipip'  # 设定来源标识
                else:
                    location_tag = '360map'
                dic = {"province": province, "city": city,
                        "district ": district, "map_street": map_street,
                        "latitude": map_latitude, "longitude": map_longitude,
                        "location_tag": location_tag}
                s = json.dumps(dic, ensure_ascii=False)
                red.hset(ip, ip, s)  # 将查询结果存入redis库中
                red.expire(ip, 604800)  # 设置过期时间7天
                print ip + "\t" + s  # 返回查询结果
            except:
                print ip
                print result
                sys.exit(0)
        else:
            print ip


if __name__ == "__main__":
    qurey_ip()

